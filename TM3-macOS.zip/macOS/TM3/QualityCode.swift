import Foundation

enum QualityCode {
    case good
    case uncertain
    case bad
    case unknown
}
